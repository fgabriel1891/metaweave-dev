Portable inputs for the palm–mammal case study
Prepared 2026-09-14 from the original local analysis inputs.

palms.tif: 51 matched palm species, binary presence with NA elsewhere.
mammals.tif: 68 matched mammal species, binary presence with NA elsewhere.
Geometry: global extent (-180, 180, -90, 90), 1-degree cells, WGS84 / EPSG:4326.
These are actual matched input ranges, not ranges reconstructed from outputs.
Species names are embedded as layer names. The two stacks have identical geometry.

fitted-models.rds: regional_web, theta_sbm, producer_lookup, consumer_lookup.
Extracted from the pre-existing palm_mammal_objects.rds without refitting.
The regional matrix contains 234 links among 51 palms and 68 mammals.
The retained cassandRa fit has seven blocks per group.

PalmFrugDatasetOCT2018.csv: unchanged local copy of the regional source dataset.
Source citation: Muñoz, Trøjelsgaard and Kissling (2019), Dryad,
https://doi.org/10.5061/dryad.rd46vq3
Only Neotropical MAMMAL records enter the case study.

To reproduce spatial results from the manuscript root in R:
source("case-palm-mammal-int/replay_case_study.R")
Requires metaweave, terra, ggplot2 and patchwork. Outputs go to replayed-results.
This preserves the archived regional fit. It does not refit cassandRa.

AUTHOR ACTION: document original palm and mammal range sources, versions,
download dates, rasterization settings, taxonomic decisions, and redistribution
conditions before sharing the input archive publicly. No public upload was made.
