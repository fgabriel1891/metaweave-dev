# Run from the manuscript root: source("case-palm-mammal-int/replay_case_study.R")
# Reuses the archived regional fit; does not rerun stochastic model fitting.
library(metaweave)
library(terra)
library(ggplot2)
library(patchwork)
case_dir <- if (dir.exists("case-palm-mammal-int")) "case-palm-mammal-int" else "."
input <- file.path(case_dir, "portable-inputs")
output <- file.path(case_dir, "replayed-results")
dir.create(output, showWarnings = FALSE)
x <- readRDS(file.path(input, "fitted-models.rds"))
distributions <- list(producers = rast(file.path(input, "palms.tif")),
                      consumers = rast(file.path(input, "mammals.tif")))
recorded_model <- probability_matrix_model(x$regional_web, "producers", "consumers")
sbm <- block_model(x$producer_lookup, x$consumer_lookup, x$theta_sbm,
                   "producers", "consumers")
a <- run_spatial_inference(distributions, recorded_model, min_species = 1L)
b <- run_spatial_inference(distributions, sbm, min_species = 1L)
stopifnot(identical(a$result$index$cell_id, b$result$index$cell_id))
d <- a$result$index
d$palm_richness <- d$row_richness
d$mammal_richness <- d$column_richness
d$recorded_links <- d$expected_links
d$expected_sbm_links <- b$result$index$expected_links
d$link_difference <- d$expected_sbm_links - d$recorded_links
old <- read.csv(file.path(case_dir, "palm-mammal-results", "palm_mammal_cell_results.csv"))
stopifnot(identical(d$cell_id, old$cell_id),
          max(abs(d$recorded_links - old$recorded_links)) < 1e-9,
          max(abs(d$expected_sbm_links - old$expected_sbm_links)) < 1e-9)
write.csv(d, file.path(output, "cell_results.csv"), row.names = FALSE)
writeRaster(a$spatial$data, file.path(output, "recorded_metrics.tif"), overwrite = TRUE)
writeRaster(b$spatial$data, file.path(output, "sbm_metrics.tif"), overwrite = TRUE)
link_limits <- range(c(d$recorded_links, d$expected_sbm_links))
difference_limit <- max(abs(d$link_difference))
panel <- function(variable, title, limits = NULL, diverging = FALSE) {
  p <- ggplot(d, aes(x, y, fill = .data[[variable]])) +
    geom_tile(width = 1, height = 1) +
    coord_equal(xlim = c(-108, -32), ylim = c(-37, 37), expand = FALSE) +
    labs(title = title, x = NULL, y = NULL, fill = NULL) +
    theme_minimal(base_size = 11) +
    theme(panel.grid = element_blank(), legend.position = "bottom",
          plot.title = element_text(size = 11), axis.text = element_text(size = 8))
  if (diverging) p + scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
     midpoint = 0, limits = c(-difference_limit, difference_limit)) else
     p + scale_fill_viridis_c(option = "C", limits = limits)
}
fig <- (panel("palm_richness", "Palm richness") |
        panel("mammal_richness", "Mammal richness") |
        panel("recorded_links", "Recorded links", link_limits)) /
       (panel("expected_sbm_links", "Expected SBM links", link_limits) |
        panel("link_difference", "SBM minus recorded links", diverging = TRUE) |
        plot_spacer()) + plot_annotation(tag_levels = "A")
ggsave(file.path(output, "palm_mammal_case_study.png"), fig,
       width = 10, height = 8, dpi = 400, bg = "white")
capture.output(sessionInfo(), file = file.path(output, "sessionInfo.txt"))
cat("PASS: portable spatial replay reproduces all 1,254 saved cells.\n")
