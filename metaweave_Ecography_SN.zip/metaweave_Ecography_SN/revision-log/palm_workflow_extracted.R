#| label: setup

library(metaweave)
library(terra)
library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)

set.seed(123)

project_dir <- Sys.getenv(
  "PALM_MAMMAL_DATA_DIR",
  unset = paste0(
    "C:/Users/gabri/Documents/PhD/",
    "Network_reconstruction_under_data_scarsity/MetaWeave/MetaWeave"
  )
)

output_dir <- file.path(getwd(), "palm-mammal-results")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
#| label: read-data

palm_grid_occ <- readRDS(file.path(
  project_dir,
  "DATA/clean_datasets/palm_ranges_grid_stack.RDS"
))

mammal_grid_occ <- readRDS(file.path(
  project_dir,
  "DATA/clean_datasets/mammal_ranges_grid_stack.RDS"
))

palm_mammal_frugivory <- read.csv(file.path(
  project_dir,
  paste0(
    "DATA/02_species_interactions/PalmDryadRepo/",
    "Munozetal2019/PalmFrugDatasetOCT2018.csv"
  )
)) |>
  filter(
    frugClass == "MAMMAL",
    biogeographicRegion == "Neotropics"
  )
#| label: harmonize-data

standardize_species <- function(x) {
  x <- trimws(tolower(as.character(x)))
  x <- gsub("[^[:alnum:]]+", "_", x)
  gsub("^_+|_+$", "", x)
}

merge_duplicate_ranges <- function(x) {
  groups <- factor(names(x), levels = unique(names(x)))
  merged <- terra::tapp(x, index = groups, fun = "sum", na.rm = TRUE)
  merged <- terra::ifel(merged > 0, 1, NA)
  names(merged) <- levels(groups)
  merged
}

remove_empty_ranges <- function(x) {
  limits <- terra::global(x, c("min", "max"), na.rm = TRUE)
  keep <- !is.na(limits$min) & !is.na(limits$max)
  x[[which(keep)]]
}

names(palm_grid_occ) <- standardize_species(names(palm_grid_occ))
names(mammal_grid_occ) <- standardize_species(names(mammal_grid_occ))

palm_grid_occ <- palm_grid_occ |>
  merge_duplicate_ranges() |>
  remove_empty_ranges()

mammal_grid_occ <- mammal_grid_occ |>
  merge_duplicate_ranges() |>
  remove_empty_ranges()

interaction_data <- palm_mammal_frugivory |>
  transmute(
    producer = standardize_species(PALM),
    consumer = standardize_species(FRUGIVORE)
  ) |>
  filter(
    !is.na(producer),
    !is.na(consumer),
    producer != "",
    consumer != ""
  ) |>
  distinct(producer, consumer)

matched_producers <- intersect(
  names(palm_grid_occ),
  unique(interaction_data$producer)
)

matched_consumers <- intersect(
  names(mammal_grid_occ),
  unique(interaction_data$consumer)
)

stopifnot(
  length(matched_producers) > 1L,
  length(matched_consumers) > 1L
)

regional_records <- interaction_data |>
  filter(
    producer %in% matched_producers,
    consumer %in% matched_consumers
  )

regional_web <- xtabs(
  ~ producer + consumer,
  data = regional_records
) |>
  as.matrix()

regional_web <- (regional_web > 0) * 1
regional_web <- regional_web[
  rowSums(regional_web) > 0,
  colSums(regional_web) > 0,
  drop = FALSE
]

analysis_producers <- rownames(regional_web)
analysis_consumers <- colnames(regional_web)

producer_ranges <- palm_grid_occ[[analysis_producers]]
consumer_ranges <- mammal_grid_occ[[analysis_consumers]]

stopifnot(
  terra::compareGeom(
    producer_ranges,
    consumer_ranges,
    stopOnError = FALSE
  ),
  !anyDuplicated(names(producer_ranges)),
  !anyDuplicated(names(consumer_ranges))
)

data_summary <- data.frame(
  palms = length(analysis_producers),
  mammals = length(analysis_consumers),
  recorded_interactions = sum(regional_web),
  regional_connectance = mean(regional_web)
)

data_summary
#| label: recorded-metaweb

recorded_model <- probability_matrix_model(
  probability_matrix = regional_web,
  row_group = "producers",
  column_group = "consumers",
  name = "recorded regional metaweb"
)
#| label: fit-sbm

if (!requireNamespace("cassandRa", quietly = TRUE)) {
  stop("Install 'cassandRa' to fit the stochastic block model.")
}

cass_network <- cassandRa::CreateListObject(regional_web)

set.seed(123)
cass_fit <- cassandRa::FitSBM(
  list = cass_network,
  n_SBM = 10,
  G = NULL
)

best_sbm <- cass_fit$SBM1
theta_sbm <- best_sbm$Omega_rs

producer_block_names <- paste0(
  "producer_block_",
  seq_len(nrow(theta_sbm))
)

consumer_block_names <- paste0(
  "consumer_block_",
  seq_len(ncol(theta_sbm))
)

rownames(theta_sbm) <- producer_block_names
colnames(theta_sbm) <- consumer_block_names

producer_lookup <- data.frame(
  species = rownames(regional_web),
  guild = producer_block_names[best_sbm$SB_H]
)

consumer_lookup <- data.frame(
  species = colnames(regional_web),
  guild = consumer_block_names[best_sbm$SB_W]
)

sbm <- block_model(
  row_lookup = producer_lookup,
  column_lookup = consumer_lookup,
  theta = theta_sbm,
  row_group = "producers",
  column_group = "consumers"
)
#| label: spatial-reconstruction

distributions <- list(
  producers = new_distribution_collection(
    producer_ranges,
    guild = "palms"
  ),
  consumers = new_distribution_collection(
    consumer_ranges,
    guild = "mammals"
  )
)

recorded_result <- run_spatial_inference(
  distributions = distributions,
  model = recorded_model,
  min_species = 1L
)

sbm_result <- run_spatial_inference(
  distributions = distributions,
  model = sbm,
  min_species = 1L
)

stopifnot(identical(
  recorded_result$result$index[, c("cell_id", "x", "y")],
  sbm_result$result$index[, c("cell_id", "x", "y")]
))
#| label: prepare-results

recorded_index <- recorded_result$result$index |>
  transmute(
    cell_id,
    x,
    y,
    palm_richness = row_richness,
    mammal_richness = column_richness,
    recorded_links = expected_links,
    recorded_connectance = mean_probability
  )

sbm_index <- sbm_result$result$index |>
  transmute(
    cell_id,
    expected_sbm_links = expected_links,
    expected_sbm_connectance = mean_probability
  )

case_study_results <- recorded_index |>
  left_join(sbm_index, by = "cell_id") |>
  mutate(
    additional_expected_links = expected_sbm_links - recorded_links,
    connectance_difference =
      expected_sbm_connectance - recorded_connectance
  )

case_summary <- case_study_results |>
  summarise(
    cells = n(),
    mean_palms = mean(palm_richness),
    mean_mammals = mean(mammal_richness),
    mean_recorded_links = mean(recorded_links),
    mean_sbm_links = mean(expected_sbm_links),
    median_additional_links = median(additional_expected_links),
    mean_recorded_connectance = mean(recorded_connectance),
    mean_sbm_connectance = mean(expected_sbm_connectance)
  )

utils::write.csv(
  case_study_results,
  file.path(output_dir, "palm_mammal_cell_results.csv"),
  row.names = FALSE
)

utils::write.csv(
  case_summary,
  file.path(output_dir, "palm_mammal_summary.csv"),
  row.names = FALSE
)

saveRDS(
  list(
    regional_web = regional_web,
    theta_sbm = theta_sbm,
    producer_lookup = producer_lookup,
    consumer_lookup = consumer_lookup,
    recorded_result = recorded_result,
    sbm_result = sbm_result
  ),
  file.path(output_dir, "palm_mammal_objects.rds")
)

case_summary
#| label: case-study-figure
#| fig-cap: "Spatial reconstruction of Neotropical palm<U+2013>mammal interaction networks. (A<U+2013>B) Palm and mammal richness in local assemblages. (C) Documented regional links whose species co-occur locally. (D) Expected links under the fitted stochastic block model. (E) Difference between expected SBM links and the recorded-metaweb baseline. These maps represent hypotheses derived from range overlap and regional interaction information, not observations of locally realized networks."
#| fig-width: 11
#| fig-height: 7

map_panel <- function(data, variable, title, diverging = FALSE) {
  plot <- ggplot(
    data,
    aes(x = x, y = y, fill = .data[[variable]])
  ) +
    geom_raster() +
    coord_equal(
      xlim = c(-150, 0),
      ylim = c(-40, 40),
      expand = FALSE
    ) +
    labs(title = title, x = NULL, y = NULL, fill = NULL) +
    theme_classic() +
    theme(
      panel.border = element_rect(fill = NA, colour = "grey60"),
      legend.position = "bottom"
    )

  if (diverging) {
    plot + scale_fill_gradient2(
      low = "#3B4CC0",
      mid = "white",
      high = "#B40426",
      midpoint = 0,
      na.value = "white"
    )
  } else {
    plot + scale_fill_viridis_c(option = "magma", na.value = "white")
  }
}

panel_a <- map_panel(case_study_results, "palm_richness", "Palm richness")
panel_b <- map_panel(case_study_results, "mammal_richness", "Mammal richness")
panel_c <- map_panel(case_study_results, "recorded_links", "Recorded links")
panel_d <- map_panel(case_study_results, "expected_sbm_links", "Expected SBM links")
panel_e <- map_panel(
  case_study_results,
  "additional_expected_links",
  "SBM minus recorded links",
  diverging = TRUE
)

case_figure <- (
  panel_a | panel_b | panel_c
) / (
  panel_d | panel_e | patchwork::plot_spacer()
) +
  plot_annotation(tag_levels = "A")

case_figure

ggsave(
  file.path(output_dir, "palm_mammal_case_study.png"),
  case_figure,
  width = 10,
  height = 8,
  units = "in",
  dpi = 600,
  bg = "white"
)
