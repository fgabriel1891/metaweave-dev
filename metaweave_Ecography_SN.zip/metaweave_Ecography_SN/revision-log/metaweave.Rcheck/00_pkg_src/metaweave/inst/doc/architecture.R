## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(metaweave)

trait_predict <- function(model, assemblage) {
  producers <- assemblage$species$producers
  consumers <- assemblage$species$consumers
  p <- outer(producers, consumers, Vectorize(function(i, j) model$parameters$score(i, j)))
  dimnames(p) <- list(producers, consumers)
  new_ecological_network(p, "probability", row_group = "producers", column_group = "consumers")
}

trait_model <- new_inference_model(
  trait_predict,
  name = "trait matching",
  parameters = list(score = function(palm, mammal) 0.5)
)

