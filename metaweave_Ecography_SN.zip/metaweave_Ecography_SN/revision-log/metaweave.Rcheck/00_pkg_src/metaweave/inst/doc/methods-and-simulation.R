## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----libraries----------------------------------------------------------------
library(metaweave)
library(terra)

set.seed(42)

## ----distributions------------------------------------------------------------
grid <- create_standard_grid(
  extent = c(0, 6, 0, 4),
  resolution = 1,
  crs = "EPSG:4326"
)

make_range <- function(template, center_x, center_y, spread) {
  xy <- terra::crds(template)
  distance <- sqrt(
    (xy[, 1] - center_x)^2 +
      (xy[, 2] - center_y)^2
  )

  layer <- terra::rast(template)
  terra::values(layer) <- ifelse(distance <= spread, 1, NA)
  layer
}

producer_parameters <- data.frame(
  species = paste0("producer_", 1:6),
  x = c(1.0, 2.0, 3.0, 4.0, 5.0, 3.0),
  y = c(1.0, 3.0, 2.0, 3.0, 1.0, 3.5),
  spread = c(2.0, 2.2, 1.8, 2.0, 1.8, 2.4)
)

consumer_parameters <- data.frame(
  species = paste0("consumer_", 1:5),
  x = c(1.5, 2.5, 4.0, 5.0, 3.0),
  y = c(2.5, 1.0, 2.0, 3.0, 3.5),
  spread = c(2.0, 1.8, 2.2, 1.8, 2.4)
)

producers <- terra::rast(lapply(seq_len(nrow(producer_parameters)), function(i) {
  make_range(
    grid,
    producer_parameters$x[i],
    producer_parameters$y[i],
    producer_parameters$spread[i]
  )
}))
names(producers) <- producer_parameters$species

consumers <- terra::rast(lapply(seq_len(nrow(consumer_parameters)), function(i) {
  make_range(
    grid,
    consumer_parameters$x[i],
    consumer_parameters$y[i],
    consumer_parameters$spread[i]
  )
}))
names(consumers) <- consumer_parameters$species

## ----block-model--------------------------------------------------------------
producer_lookup <- data.frame(
  species = names(producers),
  guild = rep(c("producer_A", "producer_B"), each = 3)
)

consumer_lookup <- data.frame(
  species = names(consumers),
  guild = c("consumer_A", "consumer_A", "consumer_B",
            "consumer_B", "consumer_B")
)

theta <- matrix(
  c(
    0.80, 0.20,
    0.25, 0.75
  ),
  nrow = 2,
  byrow = TRUE,
  dimnames = list(
    c("producer_A", "producer_B"),
    c("consumer_A", "consumer_B")
  )
)

model <- block_model(
  row_lookup = producer_lookup,
  column_lookup = consumer_lookup,
  theta = theta,
  row_group = "producers",
  column_group = "consumers"
)

## ----inference----------------------------------------------------------------
result <- run_spatial_inference(
  distributions = list(
    producers = producers,
    consumers = consumers
  ),
  model = model,
  min_species = 1
)

head(result$result$index)

## ----maps, fig.show='hold'----------------------------------------------------
plot(
  result$spatial$data[[
    c("row_richness", "column_richness", "expected_links")
  ]],
  main = c(
    "Producer richness",
    "Consumer richness",
    "Expected links"
  )
)

## ----focal-network------------------------------------------------------------
focal_id <- which.max(result$result$index$possible_links)
focal_network <- result$result$networks[[focal_id]]

round(focal_network$matrix, 2)

## ----sampling-----------------------------------------------------------------
counts_50 <- simulate_interaction_counts(
  focal_network,
  size = 50,
  seed = 1
)

counts_500 <- simulate_interaction_counts(
  focal_network,
  size = 500,
  seed = 1
)

sum(counts_50)
sum(counts_500)

## ----simulation-analysis------------------------------------------------------
target <- focal_network$matrix / sum(focal_network$matrix)

sampling_error <- function(sample_size, replicates = 100) {
  errors <- vapply(seq_len(replicates), function(i) {
    observed <- simulate_interaction_counts(
      focal_network,
      size = sample_size,
      seed = 1000 + i
    )
    observed <- observed / sum(observed)
    mean(abs(observed - target))
  }, numeric(1))

  data.frame(
    sample_size = sample_size,
    mean_absolute_error = mean(errors),
    error_sd = stats::sd(errors)
  )
}

simulation_results <- do.call(
  rbind,
  lapply(c(25, 50, 100, 250, 500), sampling_error)
)

simulation_results

plot(
  simulation_results$sample_size,
  simulation_results$mean_absolute_error,
  type = "b",
  log = "x",
  xlab = "Number of sampled interactions",
  ylab = "Mean absolute error"
)

## ----standardized-metric------------------------------------------------------
observed_connectance <- function(count_matrix) {
  sum(count_matrix > 0) / length(count_matrix)
}

connectance_100 <- rarefied_network_metric(
  prob_mat = focal_network$matrix,
  target_size = 100,
  metric = observed_connectance,
  n_per_level = 100,
  seed = 99
)

connectance_100

## ----probability-model--------------------------------------------------------
species_probabilities <- theta[
  producer_lookup$guild,
  consumer_lookup$guild,
  drop = FALSE
]

dimnames(species_probabilities) <- list(
  producer_lookup$species,
  consumer_lookup$species
)

matrix_model <- probability_matrix_model(
  probability_matrix = species_probabilities,
  row_group = "producers",
  column_group = "consumers",
  name = "species-level predictions"
)

matrix_result <- run_spatial_inference(
  distributions = list(
    producers = producers,
    consumers = consumers
  ),
  model = matrix_model,
  min_species = 1
)

