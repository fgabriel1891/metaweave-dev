## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(metaweave)

web <- new_assemblage(
  list(species = c("algae", "grazer", "fish", "bird")),
  cell_id = 1
)

model <- maxent_model(
  row_group = "species",
  constraint = "connectance",
  connectance = 0.25,
  ensemble_size = 500,
  self_links = FALSE,
  seed = 42
)

probability_web <- infer_network(web, model)
round(probability_web$matrix, 2)

## -----------------------------------------------------------------------------
degrees <- c(algae = 1, grazer = 1, fish = 1, bird = 1)

degree_model <- maxent_model(
  row_group = "species",
  constraint = "degree_sequence",
  out_degree = degrees,
  in_degree = degrees,
  ensemble_size = 250,
  self_links = FALSE,
  seed = 42,
  burn_in = 500,
  thin = 50
)

degree_web <- infer_network(web, degree_model)
round(degree_web$matrix, 2)

