.libPaths(c("C:/Users/gabri/AppData/Local/R/win-library/4.5", .libPaths()))
library(metaweave)
library(terra)
x <- readRDS("case-palm-mammal-int/palm-mammal-results/palm_mammal_objects.rds")
base <- "C:/Users/gabri/Documents/PhD/Network_reconstruction_under_data_scarsity/MetaWeave/MetaWeave"
source_text <- readLines("case-palm-mammal-int/palm_mammal_case_study.qmd", encoding = "UTF-8")
inside <- FALSE
script <- character()
for (line in source_text) {
  if (grepl("^```\\{r", line)) { inside <- TRUE; next }
  if (grepl("^```", line)) { inside <- FALSE; next }
  if (inside) script <- c(script, line)
}
writeLines(script, "revision-log/palm_workflow_extracted.R")
# Evaluate only data preparation, stopping before construction of the first model.
end <- grep("^recorded_model <-", script)[1] - 1
eval(parse(text = script[seq_len(end)]))
dir.create("case-palm-mammal-int/portable-inputs", showWarnings = FALSE)
writeRaster(producer_ranges, "case-palm-mammal-int/portable-inputs/palms.tif", overwrite = TRUE)
writeRaster(consumer_ranges, "case-palm-mammal-int/portable-inputs/mammals.tif", overwrite = TRUE)
saveRDS(x[c("regional_web", "theta_sbm", "producer_lookup", "consumer_lookup")], "case-palm-mammal-int/portable-inputs/fitted-models.rds")
capture.output(list(resolution = res(producer_ranges), extent = as.vector(ext(producer_ranges)), crs = crs(producer_ranges), original_species = c(nlyr(palm_grid_occ), nlyr(mammal_grid_occ))), file = "revision-log/range-metadata.txt")
stopifnot(isTRUE(all.equal(unname(regional_web), unname(x$regional_web))))
models <- list(recorded = probability_matrix_model(regional_web, "producers", "consumers"), sbm = block_model(x$producer_lookup, x$consumer_lookup, x$theta_sbm, "producers", "consumers"))
for (nm in names(models)) {
  fresh <- run_spatial_inference(list(producers = producer_ranges, consumers = consumer_ranges), models[[nm]], min_species = 1L)
  saved <- x[[if(nm == "recorded") "recorded_result" else "sbm_result"]]
  stopifnot(isTRUE(all.equal(fresh$result$index, saved$result$index)))
}
cat("PASS: raw interaction preparation and both spatial reconstructions reproduce saved indices.\n", file = "revision-log/spatial-verification.txt")
