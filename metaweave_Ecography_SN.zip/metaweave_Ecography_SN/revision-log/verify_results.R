.libPaths(c("C:/Users/gabri/AppData/Local/R/win-library/4.5", .libPaths()))
dir.create("revision-log", showWarnings = FALSE)
sink("revision-log/results-verification.txt", split = TRUE)
cat("Verification date:", as.character(Sys.Date()), "\n")
library(metaweave)
x <- readRDS("case-palm-mammal-int/palm-mammal-results/palm_mammal_objects.rds")
d <- read.csv("case-palm-mammal-int/palm-mammal-results/palm_mammal_cell_results.csv")
a <- x$recorded_result$result$networks
b <- x$sbm_result$result$networks
stopifnot(length(a) == nrow(d), length(b) == nrow(d))
recorded <- probability_matrix_model(x$regional_web, "producers", "consumers")
sbm <- block_model(x$producer_lookup, x$consumer_lookup, x$theta_sbm, "producers", "consumers")
for (i in seq_along(a)) {
  aa <- new_assemblage(list(producers = rownames(a[[i]]$matrix), consumers = colnames(a[[i]]$matrix)))
  stopifnot(isTRUE(all.equal(infer_network(aa, recorded)$matrix, a[[i]]$matrix)),
            isTRUE(all.equal(infer_network(aa, sbm)$matrix, b[[i]]$matrix)),
            identical(unname(dimnames(a[[i]]$matrix)), unname(dimnames(b[[i]]$matrix))),
            abs(sum(a[[i]]$matrix) - d$recorded_links[i]) < 1e-9,
            abs(sum(b[[i]]$matrix) - d$expected_sbm_links[i]) < 1e-9)
}
cat("PASS: all 1,254 local matrices reproduced with installed metaweave; CSV link counts agree.\n")
cat("Regional dimensions:", dim(x$regional_web), "links:", sum(x$regional_web), "connectance:", mean(x$regional_web), "\n")
cat("Block dimensions:", dim(x$theta_sbm), "\n")
print(summary(d))
cat("Cells with negative/zero/positive SBM-minus-recorded links:", sum(d$additional_expected_links < -1e-9), sum(abs(d$additional_expected_links) <= 1e-9), sum(d$additional_expected_links > 1e-9), "\n")
cat("Coordinate spacing (not independent confirmation of CRS):\n")
print(lapply(d[c("x", "y")], function(z) sort(unique(diff(sort(unique(z)))))))
cat("Saved raster template check:\n")
tryCatch(print(terra::res(x$recorded_result$result$template)), error = function(e) cat(conditionMessage(e), "\n"))
cat("Installed package metadata:\n")
print(packageDescription("metaweave")[c("Version", "License", "RemoteSha", "RemoteRepo")])
cat("\nRuntime package versions:\n")
for (p in c("terra", "cassandRa", "dplyr", "tidyr", "ggplot2", "patchwork")) cat(p, as.character(packageVersion(p)), "\n")
cat("\nCassandRa FitSBM implementation:\n")
print(cassandRa::FitSBM)
cat("\nSession:\n")
print(sessionInfo())
sink()
