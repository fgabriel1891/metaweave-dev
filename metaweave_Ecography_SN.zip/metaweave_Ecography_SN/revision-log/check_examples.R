.libPaths(c("C:/Users/gabri/AppData/Local/R/win-library/4.5", .libPaths()))
extract <- function(path, executable = FALSE) {
  lines <- readLines(path, encoding = "UTF-8")
  inside <- FALSE; out <- character()
  for (line in lines) {
    if (grepl(if(executable) "^```\\{r" else "^```r$", line)) {inside <- TRUE; next}
    if (grepl("^```", line)) {inside <- FALSE; next}
    if (inside) out <- c(out, line)
  }
  out
}
pdf("revision-log/example-output.pdf")
eval(parse(text = extract("article.qmd")))
stopifnot(all.equal(result$result$index$expected_links, c(2, .2)),
          all.equal(result$result$index$mean_probability, c(.5, .2)))
dev.off()
script <- extract("synthetic_benchmark.qmd", TRUE)
script <- gsub('file.path(getwd(), "synthetic-benchmark-results")',
               'file.path(getwd(), "revision-log", "synthetic-recheck")', script, fixed = TRUE)
pdf("revision-log/synthetic-recheck-plots.pdf")
eval(parse(text = script))
dev.off()
old <- read.csv("synthetic-benchmark-results/model_summary.csv")
new <- read.csv("revision-log/synthetic-recheck/model_summary.csv")
stopifnot(isTRUE(all.equal(old, new, tolerance = 1e-10)))
writeLines("PASS: introductory example and complete synthetic benchmark reproduce stated results.", "revision-log/example-verification.txt")
