library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)

results_dir <- "synthetic-benchmark-results"

site_results <- read.csv(
  file.path(results_dir, "site_level_performance.csv")
)

model_summary <- read.csv(
  file.path(results_dir, "model_summary.csv")
)

model_labels <- c(
  SBM = "Block model",
  regional_matrix = "Species-pair model",
  context_model = "Data-generating model"
)

model_colours <- c(
  "Block model" = "#D55E00",
  "Species-pair model" = "#0072B2",
  "Data-generating model" = "#009E73"
)

site_results <- site_results |>
  mutate(
    model = factor(
      model_labels[model],
      levels = unname(model_labels)
    )
  )

model_summary <- model_summary |>
  mutate(
    model = factor(
      model_labels[model],
      levels = unname(model_labels)
    )
  )

# A. Recovery of known interaction probabilities
panel_a <- ggplot(
  site_results,
  aes(x = model, y = probability_rmse, fill = model)
) +
  geom_violin(
    width = 0.85,
    alpha = 0.65,
    trim = FALSE
  ) +
  geom_boxplot(
    width = 0.18,
    outlier.shape = NA,
    colour = "black"
  ) +
  scale_fill_manual(values = model_colours) +
  labs(
    x = NULL,
    y = "Probability RMSE",
  ) +
  theme_classic() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    )
  ) + 
  ylim(c(0,0.5))

# B. Recovery of expected connectance
panel_b <- ggplot(
  site_results,
  aes(
    x = true_connectance,
    y = predicted_connectance,
    colour = model
  )
) +
  geom_abline(
    intercept = 0,
    slope = 1,
    linetype = 2,
    colour = "grey45"
  ) +
  geom_point(alpha = 0.45, size = 1.4) +
  scale_colour_manual(values = model_colours) +
  coord_equal() +
  labs(
    x = "True expected connectance",
    y = "Predicted connectance",
    colour = NULL
  ) +
  theme_classic() +
  theme(legend.position = "bottom")

# C. Performance against sampled binary interactions
score_data <- model_summary |>
  select(model, mean_brier, mean_log_loss) |>
  pivot_longer(
    cols = c(mean_brier, mean_log_loss),
    names_to = "metric",
    values_to = "value"
  ) |>
  mutate(
    metric = recode(
      metric,
      mean_brier = "Brier score",
      mean_log_loss = "Log loss"
    )
  )

panel_c <- ggplot(
  score_data,
  aes(x = model, y = value, fill = model)
) +
  geom_col(width = 0.7) +
  facet_wrap(
    ~metric,
    scales = "free_y",
    ncol = 1
  ) +
  scale_fill_manual(values = model_colours) +
  labs(
    x = NULL,
    y = NULL
  ) +
  theme_classic() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    ),
    strip.background = element_blank(),
    strip.text = element_text(face = "bold")
  )

benchmark_figure <- (
  panel_a |
    panel_b |
    panel_c
) +
  plot_annotation(
    tag_levels = "A",
  ) +
  plot_layout(widths = c(1, 1.2, 1))

ggsave(
  file.path(results_dir, "synthetic_benchmark_multipanel.png"),
  benchmark_figure,
  width = 11,
  height = 4.5,
  units = "in",
  dpi = 600,
  bg = "white"
)

benchmark_figure